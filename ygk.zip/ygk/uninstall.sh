#!/bin/bash
wp="/usr/local/ygk"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/ygk
